
import React, { useState } from "react";

// Sample Data Generator Function
const generateData = (total) => {
  const data = [];
  for (let i = 1; i <= total; i++) {
    data.push({ id: i, name: `User ${i}` });
  }
  return data;
};

const App = () => {
  const allData = generateData(100000); // 1 Lakh data

  const [currentPage, setCurrentPage] = useState(1); // Track which page is selected
  const itemsPerPage = 100; // Each page will show 100 records

  const totalPages = Math.ceil(allData.length / itemsPerPage); // Total number of pages

  // Get data for the current page
  const currentData = allData.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  // Function to change pages
  const goToPage = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  return (
    <div className="p-4">
      <h1 className="text-xl font-bold mb-4">Paging Example for 1 Lakh Data</h1>

      {/* Table to show user data */}
      <table className="w-full border">
        <thead>
          <tr className="bg-gray-200">
            <th className="border p-2">ID</th>
            <th className="border p-2">Name</th>
          </tr>
        </thead>
        <tbody>
          {currentData.map((item) => (
            <tr key={item.id}>
              <td className="border p-2">{item.id}</td>
              <td className="border p-2">{item.name}</td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Paging Controls */}
      <div className="flex gap-2 mt-4 flex-wrap">
        <button
          className="px-3 py-1 bg-blue-500 text-white rounded"
          disabled={currentPage === 1}
          onClick={() => goToPage(currentPage - 1)}
        >
          Prev
        </button>

        {/* Show only limited number of page buttons */}
        {Array.from({ length: totalPages }, (_, i) => i + 1)
          .slice(
            Math.max(currentPage - 3, 0),
            Math.min(currentPage + 2, totalPages)
          )
          .map((page) => (
            <button
              key={page}
              className={`px-3 py-1 rounded border ${
                page === currentPage ? "bg-green-500 text-white" : "bg-white"
              }`}
              onClick={() => goToPage(page)}
            >
              {page}
            </button>
          ))}

        <button
          className="px-3 py-1 bg-blue-500 text-white rounded"
          disabled={currentPage === totalPages}
          onClick={() => goToPage(currentPage + 1)}
        >
          Next
        </button>
      </div>
    </div>
  );
};

export default App;
